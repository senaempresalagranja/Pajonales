-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 18-12-2017 a las 00:57:51
-- Versión del servidor: 10.1.9-MariaDB
-- Versión de PHP: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pajonales`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `preparacion_suelo`
--

CREATE TABLE `preparacion_suelo` (
  `id_preparacionSuelo` int(11) NOT NULL,
  `latitud_ps` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `orientacionLat` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `longitud_ps` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `orientacionLon` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `profundidadpreparacion_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `tamanoterrones_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_ps` date NOT NULL,
  `Spodoptera_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Grillotalpa_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Blissus_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `GusanoAlambre_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Mocis_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Spodoptera_ps_comedor` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Panoquina_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Platinota_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Tipotidae` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `diatrea_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Rupella_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Chinches_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Sogata` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Helmintosporium_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Cercospa_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Piricularia_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Rizhoctorinia` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Gaeumanonomices` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Sarocladium` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Pseudomona_fuscovagine_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Burkholderia_glumae_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `En_la_Espiga_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Arroz_Rojo_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Liendrepuerco_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Caminadora_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Falsa_Caminadora_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Peluda_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Mona_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Guardarocio_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Pinita_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Suelda_con_suelda_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Verdolaga_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Bledo_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Batatilla_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Boton_Blanco_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Clavito_de_Agua_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Cortadera_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Coquito_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `preparacion_suelo`
--

INSERT INTO `preparacion_suelo` (`id_preparacionSuelo`, `latitud_ps`, `orientacionLat`, `longitud_ps`, `orientacionLon`, `profundidadpreparacion_ps`, `tamanoterrones_ps`, `fecha_ps`, `Spodoptera_ps`, `Grillotalpa_ps`, `Blissus_ps`, `GusanoAlambre_ps`, `Mocis_ps`, `Spodoptera_ps_comedor`, `Panoquina_ps`, `Platinota_ps`, `Tipotidae`, `diatrea_ps`, `Rupella_ps`, `Chinches_ps`, `Sogata`, `Helmintosporium_ps`, `Cercospa_ps`, `Piricularia_ps`, `Rizhoctorinia`, `Gaeumanonomices`, `Sarocladium`, `Pseudomona_fuscovagine_ps`, `Burkholderia_glumae_ps`, `En_la_Espiga_ps`, `Arroz_Rojo_ps`, `Liendrepuerco_ps`, `Caminadora_ps`, `Falsa_Caminadora_ps`, `Paja_Peluda_ps`, `Paja_Mona_ps`, `Guardarocio_ps`, `Pinita_ps`, `Suelda_con_suelda_ps`, `Verdolaga_ps`, `Bledo_ps`, `Batatilla_ps`, `Boton_Blanco_ps`, `Clavito_de_Agua_ps`, `Cortadera_ps`, `Coquito_ps`) VALUES
(9, '-122151.45', 'SUR', '45645.5456', 'ESTE', 'qq', 'q', '2017-12-27', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `r0_r1`
--

CREATE TABLE `r0_r1` (
  `id_preparacionSuelo` int(11) NOT NULL,
  `latitud_ps` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `orientacionLat` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `longitud_ps` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `orientacionLon` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `fechainicioPrimordio_ps` date NOT NULL,
  `fecha_ps` date NOT NULL,
  `Spodoptera_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Grillotalpa_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Blissus_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `GusanoAlambre_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Mocis_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Spodoptera_ps_comedor` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Panoquina_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Platinota_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Tipotidae` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `diatrea_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Rupella_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Chinches_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Sogata` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Helmintosporium_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Cercospa_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Piricularia_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Rizhoctorinia` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Gaeumanonomices` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Sarocladium` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Pseudomona_fuscovagine_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Burkholderia_glumae_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `En_la_Espiga_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Arroz_Rojo_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Liendrepuerco_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Caminadora_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Falsa_Caminadora_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Peluda_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Mona_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Guardarocio_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Pinita_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Suelda_con_suelda_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Verdolaga_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Bledo_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Batatilla_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Boton_Blanco_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Clavito_de_Agua_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Cortadera_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Coquito_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `r0_r1`
--

INSERT INTO `r0_r1` (`id_preparacionSuelo`, `latitud_ps`, `orientacionLat`, `longitud_ps`, `orientacionLon`, `fechainicioPrimordio_ps`, `fecha_ps`, `Spodoptera_ps`, `Grillotalpa_ps`, `Blissus_ps`, `GusanoAlambre_ps`, `Mocis_ps`, `Spodoptera_ps_comedor`, `Panoquina_ps`, `Platinota_ps`, `Tipotidae`, `diatrea_ps`, `Rupella_ps`, `Chinches_ps`, `Sogata`, `Helmintosporium_ps`, `Cercospa_ps`, `Piricularia_ps`, `Rizhoctorinia`, `Gaeumanonomices`, `Sarocladium`, `Pseudomona_fuscovagine_ps`, `Burkholderia_glumae_ps`, `En_la_Espiga_ps`, `Arroz_Rojo_ps`, `Liendrepuerco_ps`, `Caminadora_ps`, `Falsa_Caminadora_ps`, `Paja_Peluda_ps`, `Paja_Mona_ps`, `Guardarocio_ps`, `Pinita_ps`, `Suelda_con_suelda_ps`, `Verdolaga_ps`, `Bledo_ps`, `Batatilla_ps`, `Boton_Blanco_ps`, `Clavito_de_Agua_ps`, `Cortadera_ps`, `Coquito_ps`) VALUES
(2, '-666.666', 'SUR', '-6666.666', 'OESTE', '2017-12-03', '2017-12-31', 'yyy', 'y', 'yyy', 'yyy', 'yyy', 'yyy', 'yy', 'yyy', 'y', 'yy', 'yy', 'yy', 'yy', 'y', 'yy', 'y', 'yy', 'yy', 'yy', 'y', 'yy', 'y', 'y', 'yy', 'y', 'y', 'y', 'yy', 'yy', 'y', 'y', 'yy', 'y', 'yy', 'yy', 'y', 'yy', 'y');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `r2_r3`
--

CREATE TABLE `r2_r3` (
  `id_preparacionSuelo` int(11) NOT NULL,
  `latitud_ps` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `orientacionLat` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `longitud_ps` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `orientacionLon` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `fechafloracion_ps` date NOT NULL,
  `fecha_ps` date NOT NULL,
  `Spodoptera_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Grillotalpa_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Blissus_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `GusanoAlambre_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Mocis_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Spodoptera_ps_comedor` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Panoquina_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Platinota_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Tipotidae` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `diatrea_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Rupella_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Chinches_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Sogata` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Helmintosporium_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Cercospa_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Piricularia_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Rizhoctorinia` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Gaeumanonomices` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Sarocladium` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Pseudomona_fuscovagine_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Burkholderia_glumae_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `En_la_Espiga_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Arroz_Rojo_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Liendrepuerco_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Caminadora_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Falsa_Caminadora_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Peluda_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Mona_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Guardarocio_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Pinita_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Suelda_con_suelda_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Verdolaga_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Bledo_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Batatilla_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Boton_Blanco_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Clavito_de_Agua_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Cortadera_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Coquito_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `r2_r3`
--

INSERT INTO `r2_r3` (`id_preparacionSuelo`, `latitud_ps`, `orientacionLat`, `longitud_ps`, `orientacionLon`, `fechafloracion_ps`, `fecha_ps`, `Spodoptera_ps`, `Grillotalpa_ps`, `Blissus_ps`, `GusanoAlambre_ps`, `Mocis_ps`, `Spodoptera_ps_comedor`, `Panoquina_ps`, `Platinota_ps`, `Tipotidae`, `diatrea_ps`, `Rupella_ps`, `Chinches_ps`, `Sogata`, `Helmintosporium_ps`, `Cercospa_ps`, `Piricularia_ps`, `Rizhoctorinia`, `Gaeumanonomices`, `Sarocladium`, `Pseudomona_fuscovagine_ps`, `Burkholderia_glumae_ps`, `En_la_Espiga_ps`, `Arroz_Rojo_ps`, `Liendrepuerco_ps`, `Caminadora_ps`, `Falsa_Caminadora_ps`, `Paja_Peluda_ps`, `Paja_Mona_ps`, `Guardarocio_ps`, `Pinita_ps`, `Suelda_con_suelda_ps`, `Verdolaga_ps`, `Bledo_ps`, `Batatilla_ps`, `Boton_Blanco_ps`, `Clavito_de_Agua_ps`, `Cortadera_ps`, `Coquito_ps`) VALUES
(2, '777.777', 'NORTE', '77.777777', 'ESTE', '2017-12-26', '2017-12-31', 'uuu', 'uuu', 'uuu', 'uuu', 'uuu', 'uu', 'u', 'uu', 'u', 'u', 'u', 'u', 'u', 'u', 'u', 'u', 'uu', 'u', 'u', 'u', 'u', 'u', 'uu', 'u', 'u', 'u', 'u', 'uu', 'u', 'u', 'uu', 'u', 'u', 'uu', 'u', 'u', 'u', 'u');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `r4_r5`
--

CREATE TABLE `r4_r5` (
  `id_preparacionSuelo` int(11) NOT NULL,
  `latitud_ps` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `orientacionLat` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `longitud_ps` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `orientacionLon` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `macollas_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_ps` date NOT NULL,
  `Spodoptera_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Grillotalpa_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Blissus_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `GusanoAlambre_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Mocis_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Spodoptera_ps_comedor` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Panoquina_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Platinota_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Tipotidae` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `diatrea_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Rupella_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Chinches_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Sogata` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Helmintosporium_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Cercospa_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Piricularia_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Rizhoctorinia` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Gaeumanonomices` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Sarocladium` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Pseudomona_fuscovagine_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Burkholderia_glumae_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `En_la_Espiga_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Arroz_Rojo_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Liendrepuerco_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Caminadora_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Falsa_Caminadora_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Peluda_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Mona_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Guardarocio_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Pinita_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Suelda_con_suelda_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Verdolaga_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Bledo_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Batatilla_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Boton_Blanco_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Clavito_de_Agua_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Cortadera_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Coquito_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `r4_r5`
--

INSERT INTO `r4_r5` (`id_preparacionSuelo`, `latitud_ps`, `orientacionLat`, `longitud_ps`, `orientacionLon`, `macollas_ps`, `fecha_ps`, `Spodoptera_ps`, `Grillotalpa_ps`, `Blissus_ps`, `GusanoAlambre_ps`, `Mocis_ps`, `Spodoptera_ps_comedor`, `Panoquina_ps`, `Platinota_ps`, `Tipotidae`, `diatrea_ps`, `Rupella_ps`, `Chinches_ps`, `Sogata`, `Helmintosporium_ps`, `Cercospa_ps`, `Piricularia_ps`, `Rizhoctorinia`, `Gaeumanonomices`, `Sarocladium`, `Pseudomona_fuscovagine_ps`, `Burkholderia_glumae_ps`, `En_la_Espiga_ps`, `Arroz_Rojo_ps`, `Liendrepuerco_ps`, `Caminadora_ps`, `Falsa_Caminadora_ps`, `Paja_Peluda_ps`, `Paja_Mona_ps`, `Guardarocio_ps`, `Pinita_ps`, `Suelda_con_suelda_ps`, `Verdolaga_ps`, `Bledo_ps`, `Batatilla_ps`, `Boton_Blanco_ps`, `Clavito_de_Agua_ps`, `Cortadera_ps`, `Coquito_ps`) VALUES
(2, '-88.888888', 'SUR', '-88.88888', 'OESTE', 'iii', '2017-12-04', 'i', 'iii', 'ii', 'ii', 'ii', 'i', 'i', 'ii', 'ii', 'ii', 'ii', 'ii', 'ii', 'ii', 'ii', 'i', 'ii', 'i', 'i', 'iii', 'ii', 'i', 'ii', 'iii', 'ii', 'i', 'iii', 'ii', 'ii', 'ii', 'ii', 'ii', 'i', 'ii', 'i', 'ii', 'i', 'i');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `r6_r8`
--

CREATE TABLE `r6_r8` (
  `id_preparacionSuelo` int(11) NOT NULL,
  `latitud_ps` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `orientacionLat` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `longitud_ps` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `orientacionLon` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `numGranosPanicula_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `peso_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `vaneamiento_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_ps` date NOT NULL,
  `Spodoptera_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Grillotalpa_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Blissus_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `GusanoAlambre_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Mocis_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Spodoptera_ps_comedor` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Panoquina_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Platinota_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Tipotidae` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `diatrea_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Rupella_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Chinches_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Sogata` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Helmintosporium_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Cercospa_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Piricularia_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Rizhoctorinia` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Gaeumanonomices` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Sarocladium` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Pseudomona_fuscovagine_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Burkholderia_glumae_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `En_la_Espiga_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Arroz_Rojo_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Liendrepuerco_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Caminadora_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Falsa_Caminadora_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Peluda_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Mona_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Guardarocio_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Pinita_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Suelda_con_suelda_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Verdolaga_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Bledo_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Batatilla_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Boton_Blanco_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Clavito_de_Agua_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Cortadera_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Coquito_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `r6_r8`
--

INSERT INTO `r6_r8` (`id_preparacionSuelo`, `latitud_ps`, `orientacionLat`, `longitud_ps`, `orientacionLon`, `numGranosPanicula_ps`, `peso_ps`, `vaneamiento_ps`, `fecha_ps`, `Spodoptera_ps`, `Grillotalpa_ps`, `Blissus_ps`, `GusanoAlambre_ps`, `Mocis_ps`, `Spodoptera_ps_comedor`, `Panoquina_ps`, `Platinota_ps`, `Tipotidae`, `diatrea_ps`, `Rupella_ps`, `Chinches_ps`, `Sogata`, `Helmintosporium_ps`, `Cercospa_ps`, `Piricularia_ps`, `Rizhoctorinia`, `Gaeumanonomices`, `Sarocladium`, `Pseudomona_fuscovagine_ps`, `Burkholderia_glumae_ps`, `En_la_Espiga_ps`, `Arroz_Rojo_ps`, `Liendrepuerco_ps`, `Caminadora_ps`, `Falsa_Caminadora_ps`, `Paja_Peluda_ps`, `Paja_Mona_ps`, `Guardarocio_ps`, `Pinita_ps`, `Suelda_con_suelda_ps`, `Verdolaga_ps`, `Bledo_ps`, `Batatilla_ps`, `Boton_Blanco_ps`, `Clavito_de_Agua_ps`, `Cortadera_ps`, `Coquito_ps`) VALUES
(2, '-999.96999', 'SUR', '-99.999', 'OESTE', 'oo', 'ooo', 'ooo', '2017-12-27', 'o', 'oo', 'oo', 'ooo', 'o', 'oo', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'oo', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'oo', 'o');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `r9`
--

CREATE TABLE `r9` (
  `id_preparacionSuelo` int(11) NOT NULL,
  `latitud_ps` varchar(15) COLLATE utf8_spanish2_ci NOT NULL,
  `orientacionLat` varchar(15) COLLATE utf8_spanish2_ci NOT NULL,
  `longitud_ps` varchar(15) COLLATE utf8_spanish2_ci NOT NULL,
  `orientacionLon` varchar(15) COLLATE utf8_spanish2_ci NOT NULL,
  `numGranosPanicula_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `peso_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `vaneamiento_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `fecha_ps` date NOT NULL,
  `Spodoptera_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Grillotalpa_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Blissus_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `GusanoAlambre_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Mocis_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Spodoptera_ps_comedor` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Panoquina_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Platinota_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Tipotidae` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `diatrea_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Rupella_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Chinches_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Sogata` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Helmintosporium_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Cercospa_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Piricularia_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Rizhoctorinia` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Gaeumanonomices` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Sarocladium` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Pseudomona_fuscovagine_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Burkholderia_glumae_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `En_la_Espiga_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Arroz_Rojo_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Liendrepuerco_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Caminadora_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Falsa_Caminadora_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Peluda_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Mona_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Guardarocio_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Pinita_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Suelda_con_suelda_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Verdolaga_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Bledo_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Batatilla_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Boton_Blanco_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Clavito_de_Agua_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Cortadera_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Coquito_ps` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `r9`
--

INSERT INTO `r9` (`id_preparacionSuelo`, `latitud_ps`, `orientacionLat`, `longitud_ps`, `orientacionLon`, `numGranosPanicula_ps`, `peso_ps`, `vaneamiento_ps`, `fecha_ps`, `Spodoptera_ps`, `Grillotalpa_ps`, `Blissus_ps`, `GusanoAlambre_ps`, `Mocis_ps`, `Spodoptera_ps_comedor`, `Panoquina_ps`, `Platinota_ps`, `Tipotidae`, `diatrea_ps`, `Rupella_ps`, `Chinches_ps`, `Sogata`, `Helmintosporium_ps`, `Cercospa_ps`, `Piricularia_ps`, `Rizhoctorinia`, `Gaeumanonomices`, `Sarocladium`, `Pseudomona_fuscovagine_ps`, `Burkholderia_glumae_ps`, `En_la_Espiga_ps`, `Arroz_Rojo_ps`, `Liendrepuerco_ps`, `Caminadora_ps`, `Falsa_Caminadora_ps`, `Paja_Peluda_ps`, `Paja_Mona_ps`, `Guardarocio_ps`, `Pinita_ps`, `Suelda_con_suelda_ps`, `Verdolaga_ps`, `Bledo_ps`, `Batatilla_ps`, `Boton_Blanco_ps`, `Clavito_de_Agua_ps`, `Cortadera_ps`, `Coquito_ps`) VALUES
(3, '101010.010', 'NORTE', '-1010.0101', 'OESTE', 'ppp', 'pp', 'pp', '2017-11-28', 'pp', 'pp', 'p', 'p', 'pp', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'pp', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `siembra_s0`
--

CREATE TABLE `siembra_s0` (
  `id_preparacionSuelo` int(11) NOT NULL,
  `latitud_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `orientacionLat` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `longitud_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `orientacionLon` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `fechasiembra_ps` date NOT NULL,
  `profundidadsiembra_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `variedad_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `densidadsiembra_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_ps` date NOT NULL,
  `Spodoptera_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Grillotalpa_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Blissus_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `GusanoAlambre_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Mocis_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Spodoptera_ps_comedor` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Panoquina_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Platinota_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Tipotidae` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `diatrea_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Rupella_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Chinches_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Sogata` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Helmintosporium_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Cercospa_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Piricularia_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Rizhoctorinia` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Gaeumanonomices` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Sarocladium` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Pseudomona_fuscovagine_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Burkholderia_glumae_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `En_la_Espiga_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Arroz_Rojo_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Liendrepuerco_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Caminadora_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Falsa_Caminadora_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Peluda_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Mona_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Guardarocio_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Pinita_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Suelda_con_suelda_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Verdolaga_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Bledo_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Batatilla_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Boton_Blanco_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Clavito_de_Agua_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Cortadera_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Coquito_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `siembra_s0`
--

INSERT INTO `siembra_s0` (`id_preparacionSuelo`, `latitud_ps`, `orientacionLat`, `longitud_ps`, `orientacionLon`, `fechasiembra_ps`, `profundidadsiembra_ps`, `variedad_ps`, `densidadsiembra_ps`, `fecha_ps`, `Spodoptera_ps`, `Grillotalpa_ps`, `Blissus_ps`, `GusanoAlambre_ps`, `Mocis_ps`, `Spodoptera_ps_comedor`, `Panoquina_ps`, `Platinota_ps`, `Tipotidae`, `diatrea_ps`, `Rupella_ps`, `Chinches_ps`, `Sogata`, `Helmintosporium_ps`, `Cercospa_ps`, `Piricularia_ps`, `Rizhoctorinia`, `Gaeumanonomices`, `Sarocladium`, `Pseudomona_fuscovagine_ps`, `Burkholderia_glumae_ps`, `En_la_Espiga_ps`, `Arroz_Rojo_ps`, `Liendrepuerco_ps`, `Caminadora_ps`, `Falsa_Caminadora_ps`, `Paja_Peluda_ps`, `Paja_Mona_ps`, `Guardarocio_ps`, `Pinita_ps`, `Suelda_con_suelda_ps`, `Verdolaga_ps`, `Bledo_ps`, `Batatilla_ps`, `Boton_Blanco_ps`, `Clavito_de_Agua_ps`, `Cortadera_ps`, `Coquito_ps`) VALUES
(6, '22222.2222', 'NORTE', '-222.22222', 'OESTE', '2017-12-27', 'ww', 'ww', 'w', '2017-12-14', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'ww', 'w', 'ww', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'ww', 'w', 'w', 'ww');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `siembra_s3`
--

CREATE TABLE `siembra_s3` (
  `id_preparacionSuelo` int(11) NOT NULL,
  `latitud_ps` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `orientacionLat` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `longitud_ps` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `orientacionLon` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `fechaemergencia_ps` date NOT NULL,
  `germinacionsemilla_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `plantasemergidas_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_ps` date NOT NULL,
  `Spodoptera_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Grillotalpa_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Blissus_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `GusanoAlambre_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Mocis_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Spodoptera_ps_comedor` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Panoquina_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Platinota_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Tipotidae` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `diatrea_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Rupella_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Chinches_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Sogata` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Helmintosporium_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Cercospa_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Piricularia_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Rizhoctorinia` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Gaeumanonomices` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Sarocladium` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Pseudomona_fuscovagine_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Burkholderia_glumae_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `En_la_Espiga_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Arroz_Rojo_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Liendrepuerco_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Caminadora_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Falsa_Caminadora_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Peluda_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Mona_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Guardarocio_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Pinita_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Suelda_con_suelda_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Verdolaga_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Bledo_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Batatilla_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Boton_Blanco_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Clavito_de_Agua_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Cortadera_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Coquito_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `siembra_s3`
--

INSERT INTO `siembra_s3` (`id_preparacionSuelo`, `latitud_ps`, `orientacionLat`, `longitud_ps`, `orientacionLon`, `fechaemergencia_ps`, `germinacionsemilla_ps`, `plantasemergidas_ps`, `fecha_ps`, `Spodoptera_ps`, `Grillotalpa_ps`, `Blissus_ps`, `GusanoAlambre_ps`, `Mocis_ps`, `Spodoptera_ps_comedor`, `Panoquina_ps`, `Platinota_ps`, `Tipotidae`, `diatrea_ps`, `Rupella_ps`, `Chinches_ps`, `Sogata`, `Helmintosporium_ps`, `Cercospa_ps`, `Piricularia_ps`, `Rizhoctorinia`, `Gaeumanonomices`, `Sarocladium`, `Pseudomona_fuscovagine_ps`, `Burkholderia_glumae_ps`, `En_la_Espiga_ps`, `Arroz_Rojo_ps`, `Liendrepuerco_ps`, `Caminadora_ps`, `Falsa_Caminadora_ps`, `Paja_Peluda_ps`, `Paja_Mona_ps`, `Guardarocio_ps`, `Pinita_ps`, `Suelda_con_suelda_ps`, `Verdolaga_ps`, `Bledo_ps`, `Batatilla_ps`, `Boton_Blanco_ps`, `Clavito_de_Agua_ps`, `Cortadera_ps`, `Coquito_ps`) VALUES
(3, '333.333', 'NORTE', '-33.333333', 'OESTE', '2017-12-12', 'ee', 'ee', '2017-12-22', 'ee', 'ee', 'eee', 'ee', 'ee', 'e', 'ee', 'ee', 'ee', 'eee', 'ee', 'ee', 'ee', 'ee', 'ee', 'ee', 'ee', 'ee', 'ee', 'ee', 'ee', 'e', 'ee', 'ee', 'e', 'e', 'e', 'e', 'ee', 'e', 'e', 'e', 'e', 'e', 'e', 'e', 'e', 'e');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nombre_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `rol_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `usuario_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `password_ps` varchar(50) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nombre_ps`, `rol_ps`, `usuario_ps`, `password_ps`) VALUES
(1, 'Luis Fernando', 'ADMINISTRADOR', 'PAJONALES', 'ec6a6536ca304edf844d1d248a4f08dc');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `v3_v5`
--

CREATE TABLE `v3_v5` (
  `id_preparacionSuelo` int(11) NOT NULL,
  `latitud_ps` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `orientacionLat` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `longitud_ps` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `orientacionLon` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `fechainiciomacollamiento_ps` date NOT NULL,
  `fecha_ps` date NOT NULL,
  `Spodoptera_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Grillotalpa_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Blissus_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `GusanoAlambre_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Mocis_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Spodoptera_ps_comedor` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Panoquina_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Platinota_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Tipotidae` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `diatrea_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Rupella_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Chinches_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Sogata` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Helmintosporium_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Cercospa_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Piricularia_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Rizhoctorinia` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Gaeumanonomices` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Sarocladium` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Pseudomona_fuscovagine_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Burkholderia_glumae_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `En_la_Espiga_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Arroz_Rojo_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Liendrepuerco_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Caminadora_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Falsa_Caminadora_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Peluda_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Mona_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Guardarocio_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Pinita_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Suelda_con_suelda_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Verdolaga_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Bledo_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Batatilla_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Boton_Blanco_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Clavito_de_Agua_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Cortadera_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Coquito_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `v3_v5`
--

INSERT INTO `v3_v5` (`id_preparacionSuelo`, `latitud_ps`, `orientacionLat`, `longitud_ps`, `orientacionLon`, `fechainiciomacollamiento_ps`, `fecha_ps`, `Spodoptera_ps`, `Grillotalpa_ps`, `Blissus_ps`, `GusanoAlambre_ps`, `Mocis_ps`, `Spodoptera_ps_comedor`, `Panoquina_ps`, `Platinota_ps`, `Tipotidae`, `diatrea_ps`, `Rupella_ps`, `Chinches_ps`, `Sogata`, `Helmintosporium_ps`, `Cercospa_ps`, `Piricularia_ps`, `Rizhoctorinia`, `Gaeumanonomices`, `Sarocladium`, `Pseudomona_fuscovagine_ps`, `Burkholderia_glumae_ps`, `En_la_Espiga_ps`, `Arroz_Rojo_ps`, `Liendrepuerco_ps`, `Caminadora_ps`, `Falsa_Caminadora_ps`, `Paja_Peluda_ps`, `Paja_Mona_ps`, `Guardarocio_ps`, `Pinita_ps`, `Suelda_con_suelda_ps`, `Verdolaga_ps`, `Bledo_ps`, `Batatilla_ps`, `Boton_Blanco_ps`, `Clavito_de_Agua_ps`, `Cortadera_ps`, `Coquito_ps`) VALUES
(2, '-44.444444', 'SUR', '4.44444444', 'ESTE', '2017-12-18', '2017-12-22', 'rr', 'rr', 'rrr', 'rrr', 'rr', 'rr', 'rr', 'rrr', 'rr', 'rr', 'rr', 'rr', 'r', 'r', 'rr', 'r', 'r', 'r', 'rr', 'r', 'r', 'r', 'rr', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'rr', 'r', 'r', 'rr', 'r', 'r', 'r', 'r');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `v6_v9`
--

CREATE TABLE `v6_v9` (
  `id_preparacionSuelo` int(11) NOT NULL,
  `latitud_ps` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `orientacionLat` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `longitud_ps` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `orientacionLon` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `macollas_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_ps` date NOT NULL,
  `Spodoptera_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Grillotalpa_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Blissus_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `GusanoAlambre_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Mocis_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Spodoptera_ps_comedor` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Panoquina_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Platinota_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Tipotidae` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `diatrea_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Rupella_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Chinches_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Sogata` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Helmintosporium_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Cercospa_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Piricularia_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Rizhoctorinia` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Gaeumanonomices` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Sarocladium` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Pseudomona_fuscovagine_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Burkholderia_glumae_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `En_la_Espiga_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Arroz_Rojo_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Liendrepuerco_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Caminadora_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Falsa_Caminadora_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Peluda_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Paja_Mona_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Guardarocio_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Pinita_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Suelda_con_suelda_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Verdolaga_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Bledo_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Batatilla_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Boton_Blanco_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Clavito_de_Agua_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Cortadera_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Coquito_ps` varchar(25) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `v6_v9`
--

INSERT INTO `v6_v9` (`id_preparacionSuelo`, `latitud_ps`, `orientacionLat`, `longitud_ps`, `orientacionLon`, `macollas_ps`, `fecha_ps`, `Spodoptera_ps`, `Grillotalpa_ps`, `Blissus_ps`, `GusanoAlambre_ps`, `Mocis_ps`, `Spodoptera_ps_comedor`, `Panoquina_ps`, `Platinota_ps`, `Tipotidae`, `diatrea_ps`, `Rupella_ps`, `Chinches_ps`, `Sogata`, `Helmintosporium_ps`, `Cercospa_ps`, `Piricularia_ps`, `Rizhoctorinia`, `Gaeumanonomices`, `Sarocladium`, `Pseudomona_fuscovagine_ps`, `Burkholderia_glumae_ps`, `En_la_Espiga_ps`, `Arroz_Rojo_ps`, `Liendrepuerco_ps`, `Caminadora_ps`, `Falsa_Caminadora_ps`, `Paja_Peluda_ps`, `Paja_Mona_ps`, `Guardarocio_ps`, `Pinita_ps`, `Suelda_con_suelda_ps`, `Verdolaga_ps`, `Bledo_ps`, `Batatilla_ps`, `Boton_Blanco_ps`, `Clavito_de_Agua_ps`, `Cortadera_ps`, `Coquito_ps`) VALUES
(2, '55.55555', 'NORTE', '-55.55555', 'OESTE', 'ttt', '2017-12-14', 'ttt', 't', 'tt', 't', 'tt', 't', 't', 't', 't', 't', 't', 'tt', 't', 'tt', 't', 'tt', 'ttt', 't', 'tt', 'ttt', 'tt', 't', 'tt', 't', 'tt', 't', 't', 'tt', 't', 't', 't', 'tt', 't', 'tt', 'tt', 'tt', 'tt', 'tt');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `preparacion_suelo`
--
ALTER TABLE `preparacion_suelo`
  ADD PRIMARY KEY (`id_preparacionSuelo`);

--
-- Indices de la tabla `r0_r1`
--
ALTER TABLE `r0_r1`
  ADD PRIMARY KEY (`id_preparacionSuelo`);

--
-- Indices de la tabla `r2_r3`
--
ALTER TABLE `r2_r3`
  ADD PRIMARY KEY (`id_preparacionSuelo`);

--
-- Indices de la tabla `r4_r5`
--
ALTER TABLE `r4_r5`
  ADD PRIMARY KEY (`id_preparacionSuelo`);

--
-- Indices de la tabla `r6_r8`
--
ALTER TABLE `r6_r8`
  ADD PRIMARY KEY (`id_preparacionSuelo`);

--
-- Indices de la tabla `r9`
--
ALTER TABLE `r9`
  ADD PRIMARY KEY (`id_preparacionSuelo`);

--
-- Indices de la tabla `siembra_s0`
--
ALTER TABLE `siembra_s0`
  ADD PRIMARY KEY (`id_preparacionSuelo`);

--
-- Indices de la tabla `siembra_s3`
--
ALTER TABLE `siembra_s3`
  ADD PRIMARY KEY (`id_preparacionSuelo`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`);

--
-- Indices de la tabla `v3_v5`
--
ALTER TABLE `v3_v5`
  ADD PRIMARY KEY (`id_preparacionSuelo`);

--
-- Indices de la tabla `v6_v9`
--
ALTER TABLE `v6_v9`
  ADD PRIMARY KEY (`id_preparacionSuelo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `preparacion_suelo`
--
ALTER TABLE `preparacion_suelo`
  MODIFY `id_preparacionSuelo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT de la tabla `r0_r1`
--
ALTER TABLE `r0_r1`
  MODIFY `id_preparacionSuelo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `r2_r3`
--
ALTER TABLE `r2_r3`
  MODIFY `id_preparacionSuelo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `r4_r5`
--
ALTER TABLE `r4_r5`
  MODIFY `id_preparacionSuelo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `r6_r8`
--
ALTER TABLE `r6_r8`
  MODIFY `id_preparacionSuelo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `r9`
--
ALTER TABLE `r9`
  MODIFY `id_preparacionSuelo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `siembra_s0`
--
ALTER TABLE `siembra_s0`
  MODIFY `id_preparacionSuelo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de la tabla `siembra_s3`
--
ALTER TABLE `siembra_s3`
  MODIFY `id_preparacionSuelo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `v3_v5`
--
ALTER TABLE `v3_v5`
  MODIFY `id_preparacionSuelo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `v6_v9`
--
ALTER TABLE `v6_v9`
  MODIFY `id_preparacionSuelo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
